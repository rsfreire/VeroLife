<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Soap_client extends CI_controller {

  private $wsdl, $client;

  public function __construct() {
      parent::__construct();
      global $wsdl, $client;

      $this->load->library("Nusoap_lib");
      $proxyhost = isset($_POST['proxyhost']) ? $_POST['proxyhost'] : '';
      $proxyport = isset($_POST['proxyport']) ? $_POST['proxyport'] : '';
      $proxyusername = isset($_POST['proxyusername']) ? $_POST['proxyusername'] : '';
      $proxypassword = isset($_POST['proxypassword']) ? $_POST['proxypassword'] : '';

      $wsdl = "http://verolife02.cloudapp.net:5030/Beneficiario.svc?wsdl";
      $client = new nusoap_client($wsdl, 'wsdl', $proxyhost, $proxyport, $proxyusername, $proxypassword);

      $err = $client->getError();
      if ($err) {
          echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
      }
  }

  public function index() {
      global $wsdl, $client;

      try {
          $param = array('matricula' => "0010002000003000");
          
          $client->soap_defencoding = 'UTF-8';
          $client->decode_utf8 = false;

          $result = $client->call('GetBeneficiarios', $param, '', '', false, true);

          echo '<h2>Result</h2><pre>';
          print_r($result);
          echo '</pre>';
      } catch (SoapFault $exception) {
          echo $exception;
      }

      // echo '<h2>Request</h2><pre>' . htmlspecialchars($client->request, ENT_QUOTES) . '</pre>';
      // echo '<h2>Response</h2><pre>' . htmlspecialchars($client->response, ENT_QUOTES) . '</pre>';
      //echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->debug_str, ENT_QUOTES) . '</pre>'; //this generates a lot of text!
  }
}