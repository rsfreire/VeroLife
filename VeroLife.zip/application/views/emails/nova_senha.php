<!DOCTYPE html>
<html>
<head>
<title>VeroLife</title>
</head>
<body>

<h1>Olá,</h1>
<p>Sua nova senha é: <?php echo $email_data['senha']; ?></p>

</body>
</html>